package com.studio.petgame;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ButtonBarLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.intellij.lang.annotations.JdkConstants;

import java.util.IllegalFormatCodePointException;
import java.util.Timer;
import java.util.TimerTask;
import com.studio.petgame.R;
import android.content.SharedPreferences;

public class MainActivity extends AppCompatActivity {

    public class GameplayCore {
        boolean GameStarted = false;
        int CurrentHappyValue = 100, CurrentFoodValue = 100, CurrentSleepValue = 100;
        float HappyRate = 2, FoodRate = 2, SleepRate = 1;
        float HappyButtonRate = 20, FoodButtonRate = 30, SleepButtonRate = 40;
        float GameTickRate = 1;
        int Healths = 3;
        int BestTime, CurrentTime = 0;

        ProgressBar Happy_PBar = (ProgressBar) findViewById(R.id.Happy_PBar);
        ProgressBar Food_PBar = (ProgressBar) findViewById(R.id.Food_PBar);
        ProgressBar Fatigue_PBar = (ProgressBar) findViewById(R.id.Fatigue_PBar);
        LinearLayout ButtonLayout = (LinearLayout) findViewById(R.id.ButtonLayout);
        TextView CurrentTimeText = (TextView) findViewById(R.id.CurrentTimeText);
        TextView BestTimeText = (TextView) findViewById(R.id.textView2);
        ImageView PetsImage = (ImageView) findViewById(R.id.PetImage);

        Button StartButton = (Button) findViewById(R.id.StartButton);
        Button FoodButton = (Button) findViewById(R.id.FoodButton);
        Button PlayButton  = (Button) findViewById(R.id.PlayButton);
        Button SleepButton = (Button) findViewById(R.id.SleepButton);


        Timer GameTickTimer;
        TimerTask GameplayTickTask;

        public static final String App_Savegame = "savegame";
        public static final String APP_PREFERENCES_COUNTER = "counter";
        SharedPreferences sPref;
        final String SAVE = "Save";




        public void FirstLaunchGame() {
            ResetGameStats();
            GameStarted = false;
            LoadGame();
            UpdateProgressBarsInfo();
            UpdateCurrentTimeTextInfo();
            UpdateBestTimeTextInfo();
            CreateGameplayTimer();


            StartButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    StartGame();
                }
            });

            FoodButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AddStat(1);
                }
            });

            PlayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AddStat(2);
                }
            });

            SleepButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AddStat(3);
                }
            });

        }
        public void SaveGame() {
            sPref = getSharedPreferences("Save", MODE_PRIVATE);
            SharedPreferences.Editor ed = sPref.edit();
            ed.putInt(SAVE, BestTime);
            ed.commit();
        }

        public void LoadGame() {
            sPref = getSharedPreferences("Save", MODE_PRIVATE);
            BestTime = sPref.getInt(SAVE, 0);
        }
        public void StartGame() {
            ResetGameStats();
            GameStarted = true;
            SwitchControlsButtonsVisability(true);
            UpdateProgressBarsInfo();
            UpdateCurrentTimeTextInfo();
            UpdateBestTimeTextInfo();
        }

        public void StopGame() {
            GameStarted = false;
            SwitchControlsButtonsVisability(false);
            ChangePetImage(5);
            SaveGame();
        }

        public void ResetGameStats() {
            Healths = 3;
            CurrentHappyValue = 100;
            CurrentFoodValue = 100;
            CurrentSleepValue = 100;
            GameTickRate = 1;
            CurrentTime = 0;
        }

        public void SpeedUpGameplay(){
            GameTickRate = (CurrentTime+15) / 15;
        }

        public void CreateGameplayTimer(){
            GameTickTimer = new Timer();
            GameplayTickTask = new TimerTask() {
                public void run() {
                    GameplayTick();
                }
            };
            GameTickTimer.schedule(GameplayTickTask,0,1000);
        }

        public void GameplayTick() {
            if (GameStarted) {
            CurrentTime++;
            SpeedUpGameplay();
            CurrentHappyValue -= HappyRate * GameTickRate;
            CurrentFoodValue -= FoodRate * GameTickRate;
            CurrentSleepValue -= SleepRate * GameTickRate;

            if ((CurrentFoodValue<50) || (CurrentHappyValue<50) || (CurrentSleepValue<50)) ChangePetImage(4);
            else ChangePetImage(2);


            UpdateProgressBarsInfo();
            UpdateCurrentTimeTextInfo();
            UpdateBestTimeTextInfo();
            CheckWinOrLoseCondition();
            }
        }
        public void AddStat(int statID){
          switch (statID) {
                case 1:
                    CurrentFoodValue += FoodButtonRate;
                    ChangePetImage(1);
                    if (CurrentFoodValue>100) {
                        CurrentFoodValue = 100;
                        DealDamage();
                    }
                    break;
                case 2:
                    CurrentHappyValue += HappyButtonRate;
                    ChangePetImage(3);
                    if (CurrentHappyValue>100) {
                        CurrentHappyValue = 100;
                        DealDamage();
                    }
                    break;
                case 3:
                    CurrentSleepValue += SleepButtonRate;
                    if (CurrentSleepValue>100) {
                        CurrentSleepValue = 100;
                        DealDamage();
                    }
                    break;
                default:
                    break;
            }

            UpdateProgressBarsInfo();
            CheckWinOrLoseCondition();
        }

        public void CheckWinOrLoseCondition() {
        if ((CurrentFoodValue<0)  || (CurrentHappyValue<0) || (SleepButtonRate<0) || (Healths<0)) {
            StopGame();
            }
        }

        public void DealDamage()
        {
            Healths--;
        }

        public void UpdateProgressBarsInfo() {
            Happy_PBar.setProgress(CurrentHappyValue);
            Food_PBar.setProgress(CurrentFoodValue);
            Fatigue_PBar.setProgress(CurrentSleepValue);
        }

        public void UpdateCurrentTimeTextInfo() {
            //CurrentTimeText.setText(""+CurrentTime);
            CurrentTimeText.post(new Runnable() {
                @Override
                public void run() {
                    CurrentTimeText.setText(Integer.toString(CurrentTime));
                }
            });
        }

        public void UpdateBestTimeTextInfo() {
            if (CurrentTime > BestTime) {
                BestTime = CurrentTime;
            }
            BestTimeText.post(new Runnable() {
                @Override
                public void run() {
                    BestTimeText.setText(Integer.toString(BestTime));
                }
            });
        }

        public void SwitchControlsButtonsVisability(boolean SwitchVar) {
                if (SwitchVar) {
                    ButtonLayout.post(new Runnable() {
                        @Override
                        public void run() {
                            ButtonLayout.setVisibility(View.VISIBLE);
                        }
                    });
                    StartButton.post(new Runnable() {
                        @Override
                        public void run() {
                            StartButton.setVisibility(View.GONE);
                        }
                    });
                } else {
                    ButtonLayout.post(new Runnable() {
                        @Override
                        public void run() {
                            ButtonLayout.setVisibility(View.GONE);
                        }
                    });
                    StartButton.post(new Runnable() {
                        @Override
                        public void run() {
                            StartButton.setVisibility(View.VISIBLE);
                        }
                    });
               }
        }

        public void ChangePetImage(int ImageID) {
            switch (ImageID) {
                case 1:
                    PetsImage.post(new Runnable() {
                    @Override
                    public void run() {
                        PetsImage.setImageResource(R.drawable.food);
                    }
                });
                    break;
                case 2:
                    PetsImage.post(new Runnable() {
                        @Override
                        public void run() {
                            PetsImage.setImageResource(R.drawable.happy);
                        }
                    });
                    break;
                case 3:
                    PetsImage.post(new Runnable() {
                        @Override
                        public void run() {
                            PetsImage.setImageResource(R.drawable.play);
                        }
                    });
                    break;
                case 4:
                    PetsImage.post(new Runnable() {
                        @Override
                        public void run() {
                            PetsImage.setImageResource(R.drawable.sad);
                        }
                    });
                    break;
                case 5:
                    PetsImage.post(new Runnable() {
                        @Override
                        public void run() {
                            PetsImage.setImageResource(R.drawable.death);
                        }
                    });
                    break;
                default:
                    break;
            }
        }

    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        GameplayCore GameSession  = new GameplayCore();
        GameSession.FirstLaunchGame();
    }
}


